package com.example.demo.demos.b;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BController {
    @Autowired
    private RedisTemplate redisTemplate;

/*   @RequestMapping("B")
    public ModelAndView B() {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("a");
        modelAndView.addObject("a", "aaa");
        return modelAndView;
    }*/
    @RequestMapping("B")
    public String model(Model model){
        model.addAttribute("b","Bbb");
        return "b";
    }

    @RequestMapping("/save")
    public void save(String id,String name){
        redisTemplate.opsForValue().set(id,name);
    }
}
