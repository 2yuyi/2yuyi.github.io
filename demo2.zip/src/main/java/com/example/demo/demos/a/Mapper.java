package com.example.demo.demos.a;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;

@org.apache.ibatis.annotations.Mapper
public interface Mapper {
    @Insert("INSERT INTO t_biao(id,name)" + "values (#{id},#{name})")
    public Integer insert(Integer id, String name);

    @Delete("delete from t_biao where id = #{id}")
    public Integer del();
}
